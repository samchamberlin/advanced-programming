package editor;

public class Pixel {

    public int R;
    public int G;
    public int B;

    public Pixel(int r, int g, int b){
        R = r;
        G = g;
        B = b;
    }

    public int getR() {
        return R;
    }

    public int getG() {
        return G;
    }

    public int getB() {
        return B;
    }

//    public void setR(int r) {
//        R = r;
//    }
//
//    public void setG(int g) {
//        G = g;
//    }
//
//    public void setB(int b) {
//        B = b;
//    }


}
